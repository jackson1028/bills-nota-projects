import { CustomerList } from "@/components/customer-list"

export default function CustomerPage() {
  return (
    <div className="container mx-auto p-4">
      <CustomerList />
    </div>
  )
}

