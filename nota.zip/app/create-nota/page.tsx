"use client"

import { CreateNota } from "@/components/create-nota"

export default function CreateNotaPage() {
  return <CreateNota />
}

