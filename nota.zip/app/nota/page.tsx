import { NotaList } from "@/components/nota-list"

export default function NotaListPage() {
  return <NotaList />
}

